package com.parkourai.bot;

import com.parkourai.ParkourAIMod;
import com.parkourai.ai.Action;
import com.parkourai.ai.GameState;
import com.parkourai.ai.ParkourAgent;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/**
 * Translates AI actions into actual player inputs.
 * Also handles:
 *  - checkpoint detection (did we land on a new platform?)
 *  - fall detection (reward punishment)
 *  - demonstration recording (when you play and we watch)
 */
public class BotController {

    private final ParkourAgent agent;

    // Bot mode flags
    private boolean active = false;  // is the AI controlling the player?
    private BlockPos goalBlock = null;

    // Checkpoint tracking
    private double lastY = 0;
    private Vec3d lastPos = Vec3d.ZERO;
    private int ticksOnSameBlock = 0;
    private int highestYReached = Integer.MIN_VALUE;

    // Throttle: only take an action every N ticks so the bot doesn't twitch
    private static final int TICK_INTERVAL = 4;
    private int tickCounter = 0;

    // Falling detection
    private static final double FALL_THRESHOLD = -3.0; // blocks fallen before we penalise

    public BotController(ParkourAgent agent) {
        this.agent = agent;
    }

    // -------------------------------------------------------------------------
    // Called every client tick
    // -------------------------------------------------------------------------

    public void tick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null) return;

        // Always observe in teach mode (recording your own moves)
        if (agent.isTeachMode()) {
            observePlayerForTeaching(client);
        }

        if (!active) return;

        tickCounter++;
        if (tickCounter < TICK_INTERVAL) return;
        tickCounter = 0;

        // 1. Capture current state
        GameState state = GameState.capture(client, goalBlock);

        // 2. Compute automatic reward based on what happened since last tick
        double reward = computeAutoReward(player, state);

        // 3. Update Q-table with last action's outcome
        agent.applyReward(reward, state);

        // 4. Select next action
        Action action = agent.selectAction(state);

        // 5. Execute that action
        executeAction(action, player);

        // 6. Update tracking
        lastPos = player.getPos();
        lastY = player.getY();
    }

    // -------------------------------------------------------------------------
    // Automatic reward shaping
    // -------------------------------------------------------------------------

    private double computeAutoReward(ClientPlayerEntity player, GameState state) {
        double reward = ParkourAgent.REWARD_IDLE; // small penalty for every step (encourages speed)

        Vec3d pos = player.getPos();

        // Reward for progressing toward goal
        if (goalBlock != null) {
            double prevDist = lastPos.distanceTo(Vec3d.ofCenter(goalBlock));
            double curDist = pos.distanceTo(Vec3d.ofCenter(goalBlock));
            if (curDist < prevDist) {
                reward += ParkourAgent.REWARD_MOVED_TO_GOAL;
            } else {
                reward += ParkourAgent.REWARD_MOVED_AWAY;
            }
        }

        // Reward for reaching a new height (climbing the parkour)
        int curY = (int) pos.y;
        if (curY > highestYReached) {
            reward += (curY - highestYReached) * 1.0; // 1 reward per block height gained
            highestYReached = curY;
        }

        // Punish falling significantly
        double yDrop = pos.y - lastY;
        if (yDrop < FALL_THRESHOLD) {
            reward += ParkourAgent.REWARD_FELL;
            highestYReached = (int) pos.y; // reset height baseline
        }

        // Punish being stuck on the same block
        if (pos.squaredDistanceTo(lastPos) < 0.01) {
            ticksOnSameBlock++;
            if (ticksOnSameBlock > 20) {
                reward -= 0.5; // stuck penalty
            }
        } else {
            ticksOnSameBlock = 0;
        }

        return reward;
    }

    // -------------------------------------------------------------------------
    // Action execution — translate enum to keyboard inputs
    // -------------------------------------------------------------------------

    private void executeAction(Action action, ClientPlayerEntity player) {
        // Clear all movement inputs first
        var options = MinecraftClient.getInstance().options;
        options.forwardKey.setPressed(false);
        options.backKey.setPressed(false);
        options.leftKey.setPressed(false);
        options.rightKey.setPressed(false);
        options.jumpKey.setPressed(false);
        options.sprintKey.setPressed(false);

        float yaw = player.getYaw();

        switch (action) {
            case MOVE_FORWARD   -> options.forwardKey.setPressed(true);
            case MOVE_BACK      -> options.backKey.setPressed(true);
            case STRAFE_LEFT    -> options.leftKey.setPressed(true);
            case STRAFE_RIGHT   -> options.rightKey.setPressed(true);
            case JUMP           -> options.jumpKey.setPressed(true);
            case SPRINT_FORWARD -> {
                options.forwardKey.setPressed(true);
                options.sprintKey.setPressed(true);
            }
            case SPRINT_JUMP    -> {
                options.forwardKey.setPressed(true);
                options.sprintKey.setPressed(true);
                options.jumpKey.setPressed(true);
            }
            case TURN_LEFT_SMALL  -> player.setYaw(yaw - 15);
            case TURN_RIGHT_SMALL -> player.setYaw(yaw + 15);
            case TURN_LEFT_LARGE  -> player.setYaw(yaw - 45);
            case TURN_RIGHT_LARGE -> player.setYaw(yaw + 45);
            case STOP             -> {} // do nothing — already cleared
        }
    }

    // -------------------------------------------------------------------------
    // Teach mode: observe YOUR player inputs and record them
    // -------------------------------------------------------------------------

    private void observePlayerForTeaching(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null) return;

        var options = client.options;
        Action inferred = Action.STOP;

        boolean fwd    = options.forwardKey.isPressed();
        boolean sprint = options.sprintKey.isPressed();
        boolean jump   = options.jumpKey.isPressed();
        boolean back   = options.backKey.isPressed();
        boolean left   = options.leftKey.isPressed();
        boolean right  = options.rightKey.isPressed();

        if (fwd && sprint && jump) inferred = Action.SPRINT_JUMP;
        else if (fwd && sprint)   inferred = Action.SPRINT_FORWARD;
        else if (fwd)             inferred = Action.MOVE_FORWARD;
        else if (back)            inferred = Action.MOVE_BACK;
        else if (left)            inferred = Action.STRAFE_LEFT;
        else if (right)           inferred = Action.STRAFE_RIGHT;
        else if (jump)            inferred = Action.JUMP;

        GameState state = GameState.capture(client, goalBlock);
        agent.recordDemonstration(state, inferred);
    }

    // -------------------------------------------------------------------------
    // Public control API — called from TrainerCommands
    // -------------------------------------------------------------------------

    public void setActive(boolean active) {
        this.active = active;
        if (active) {
            highestYReached = Integer.MIN_VALUE;
            ticksOnSameBlock = 0;
            ParkourAIMod.LOGGER.info("[ParkourAI] Bot activated.");
        } else {
            ParkourAIMod.LOGGER.info("[ParkourAI] Bot deactivated.");
            // Clear all keys when stopping
            var options = MinecraftClient.getInstance().options;
            if (options != null) {
                options.forwardKey.setPressed(false);
                options.backKey.setPressed(false);
                options.leftKey.setPressed(false);
                options.rightKey.setPressed(false);
                options.jumpKey.setPressed(false);
                options.sprintKey.setPressed(false);
            }
        }
    }

    public boolean isActive() { return active; }

    public void setGoal(BlockPos goal) {
        this.goalBlock = goal;
        ParkourAIMod.LOGGER.info("[ParkourAI] Goal set to {}", goal);
    }

    public BlockPos getGoal() { return goalBlock; }

    public void notifyCheckpointReached() {
        agent.applyReward(ParkourAgent.REWARD_CHECKPOINT, GameState.dummy());
        ParkourAIMod.LOGGER.info("[ParkourAI] Checkpoint reached! +{} reward", ParkourAgent.REWARD_CHECKPOINT);
    }
}
