package com.parkourai.commands;

import com.parkourai.ParkourAIMod;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

/**
 * Chat command handler.
 *
 * Commands (type in chat — they are intercepted BEFORE being sent to the server):
 *
 *   /ai help          — show all commands
 *   /ai start         — activate the bot (AI takes control)
 *   /ai stop          — deactivate the bot (you take control)
 *   /ai good          — reward last action positively
 *   /ai bad           — penalise last action negatively
 *   /ai teach         — start teach mode (you play, bot learns)
 *   /ai learn         — stop teach mode
 *   /ai goal          — set the goal to your current position (or a block ahead)
 *   /ai goal x y z    — set goal to explicit coordinates
 *   /ai checkpoint    — tell the bot it reached a checkpoint
 *   /ai status        — print Q-table size, epsilon, etc.
 *   /ai save          — force-save the Q-table
 *   /ai reset         — wipe learned knowledge and start fresh
 */
public class TrainerCommands {

    public static void register() {
        ClientSendMessageEvents.ALLOW_CHAT.register(message -> {
            if (message.startsWith("/ai ") || message.equals("/ai")) {
                handleCommand(message.trim());
                return false; // don't send to server
            }
            return true;
        });
    }

    private static void handleCommand(String raw) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) return;

        String[] parts = raw.split("\\s+");
        if (parts.length < 2) {
            printHelp(client);
            return;
        }

        String sub = parts[1].toLowerCase();

        switch (sub) {
            case "help"       -> printHelp(client);
            case "start"      -> {
                ParkourAIMod.botController.setActive(true);
                msg(client, "§a[AI] Bot started! I'm now controlling your character.");
            }
            case "stop"       -> {
                ParkourAIMod.botController.setActive(false);
                msg(client, "§e[AI] Bot stopped. You have control.");
            }
            case "good"       -> {
                ParkourAIMod.agent.trainerGood();
                msg(client, "§a[AI] ✓ Positive reward given to last action.");
            }
            case "bad"        -> {
                ParkourAIMod.agent.trainerBad();
                msg(client, "§c[AI] ✗ Negative reward given to last action.");
            }
            case "teach"      -> {
                ParkourAIMod.agent.startTeachMode();
                msg(client, "§b[AI] Teach mode ON — play the parkour now. I'm watching you!");
                msg(client, "§7Type /ai learn when done.");
            }
            case "learn"      -> {
                ParkourAIMod.agent.stopTeachMode();
                msg(client, "§a[AI] Learned from your demonstration!");
            }
            case "goal"       -> handleGoal(client, parts);
            case "checkpoint" -> {
                ParkourAIMod.botController.notifyCheckpointReached();
                msg(client, "§a[AI] Checkpoint registered! +10 reward.");
            }
            case "status"     -> {
                var agent = ParkourAIMod.agent;
                var bot   = ParkourAIMod.botController;
                msg(client, "§6[AI] Status:");
                msg(client, String.format("§7  Active: %s", bot.isActive() ? "§aYES" : "§cNO"));
                msg(client, String.format("§7  Teach mode: %s", agent.isTeachMode() ? "§aON" : "§7OFF"));
                msg(client, String.format("§7  Q-table states: §f%d", agent.getQTableSize()));
                msg(client, String.format("§7  Exploration rate (ε): §f%.3f", agent.getEpsilon()));
                msg(client, String.format("§7  Total steps: §f%d", agent.getStepCount()));
                msg(client, String.format("§7  Goal: §f%s", bot.getGoal() != null ? bot.getGoal().toShortString() : "none"));
            }
            case "save"       -> {
                ParkourAIMod.agent.save();
                msg(client, "§a[AI] Q-table saved.");
            }
            case "reset"      -> {
                ParkourAIMod.agent.reset();
                msg(client, "§c[AI] Q-table wiped. Starting fresh.");
            }
            default           -> msg(client, "§c[AI] Unknown command. Type /ai help.");
        }
    }

    private static void handleGoal(MinecraftClient client, String[] parts) {
        if (parts.length == 5) {
            // Explicit coordinates
            try {
                int x = Integer.parseInt(parts[2]);
                int y = Integer.parseInt(parts[3]);
                int z = Integer.parseInt(parts[4]);
                BlockPos goal = new BlockPos(x, y, z);
                ParkourAIMod.botController.setGoal(goal);
                msg(client, String.format("§a[AI] Goal set to %d %d %d", x, y, z));
            } catch (NumberFormatException e) {
                msg(client, "§c[AI] Usage: /ai goal <x> <y> <z>");
            }
        } else {
            // Use player's current position
            if (client.player == null) return;
            BlockPos pos = client.player.getBlockPos();
            ParkourAIMod.botController.setGoal(pos);
            msg(client, String.format("§a[AI] Goal set to your position: %s", pos.toShortString()));
        }
    }

    private static void printHelp(MinecraftClient client) {
        msg(client, "§6=== Parkour AI Commands ===");
        msg(client, "§e/ai start      §7— AI takes control and starts running parkour");
        msg(client, "§e/ai stop       §7— you take control back");
        msg(client, "§e/ai good       §7— reward last action (it did the right thing)");
        msg(client, "§e/ai bad        §7— punish last action (it went the wrong way)");
        msg(client, "§e/ai teach      §7— you play, AI watches and copies your movement");
        msg(client, "§e/ai learn      §7— stop teach mode, absorb the lesson");
        msg(client, "§e/ai goal       §7— set parkour goal to your current location");
        msg(client, "§e/ai goal x y z §7— set goal to exact coordinates");
        msg(client, "§e/ai checkpoint §7— manually tell AI it reached a checkpoint");
        msg(client, "§e/ai status     §7— show Q-table stats and current settings");
        msg(client, "§e/ai save       §7— force save learning data to disk");
        msg(client, "§e/ai reset      §7— wipe all learning and start fresh");
        msg(client, "§7Learning is saved automatically every 500 steps.");
    }

    private static void msg(MinecraftClient client, String text) {
        if (client.player != null) {
            client.player.sendMessage(Text.literal(text), false);
        }
    }
}
