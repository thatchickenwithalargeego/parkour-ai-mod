package com.parkourai.ai;

import com.parkourai.ParkourAIMod;
import net.minecraft.util.math.BlockPos;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * Q-Learning agent for parkour.
 *
 * The Q-table maps (state, action) → expected reward.
 * On each tick we:
 *  1. Observe the current state
 *  2. Pick the best action (with some exploration noise)
 *  3. Execute it
 *  4. Observe the reward (automatic + manual from trainer)
 *  5. Update the Q-table
 *
 * Trainer feedback (you typing /ai good or /ai bad) injects extra reward
 * into the last (state, action) pair — this is the "learning from you" part.
 */
public class ParkourAgent {

    // Hyper-parameters
    private static final double ALPHA       = 0.15;   // learning rate
    private static final double GAMMA       = 0.95;   // discount factor
    private static final double EPSILON_START = 0.9; // initial exploration rate
    private static final double EPSILON_MIN   = 0.05;
    private static final double EPSILON_DECAY = 0.9995;

    // Rewards
    public static final double REWARD_TRAINER_GOOD   =  5.0;
    public static final double REWARD_TRAINER_BAD    = -5.0;
    public static final double REWARD_MOVED_TO_GOAL  =  0.5;
    public static final double REWARD_MOVED_AWAY     = -0.1;
    public static final double REWARD_FELL           = -3.0;
    public static final double REWARD_CHECKPOINT     = 10.0;
    public static final double REWARD_IDLE           = -0.05;

    // Q-table: stateKey → double[Action.COUNT]
    private final Map<Integer, double[]> qTable = new HashMap<>();
    private double epsilon = EPSILON_START;
    private final Random rng = new Random();

    // Memory for learning
    private GameState lastState = null;
    private Action lastAction = null;
    private int stepCount = 0;

    // Save path
    private static final Path SAVE_PATH = Path.of("config/parkouraid_qtable.bin");

    // --- Demonstration mode ---
    // When you teach the bot by playing yourself, we record your states+actions
    private boolean teachMode = false;
    private final List<int[]> teachBuffer = new ArrayList<>(); // [stateKey, actionOrdinal]

    public ParkourAgent() {
        load(); // attempt to restore prior knowledge
    }

    // -------------------------------------------------------------------------
    // Main action selection
    // -------------------------------------------------------------------------

    /**
     * Choose the next action given the current state.
     * Uses epsilon-greedy: explore randomly sometimes, exploit best known action otherwise.
     */
    public Action selectAction(GameState state) {
        lastState = state;

        if (rng.nextDouble() < epsilon) {
            // Explore — random action
            lastAction = Action.VALUES[rng.nextInt(Action.COUNT)];
        } else {
            // Exploit — best known action
            lastAction = bestAction(state);
        }

        // Decay exploration over time
        epsilon = Math.max(EPSILON_MIN, epsilon * EPSILON_DECAY);
        stepCount++;

        return lastAction;
    }

    /**
     * Apply a reward and update the Q-table (called after each tick).
     */
    public void applyReward(double reward, GameState nextState) {
        if (lastState == null || lastAction == null) return;

        int sKey = lastState.encode();
        int aIdx = lastAction.ordinal();

        double[] q = getQ(sKey);
        double[] qNext = getQ(nextState.encode());

        double maxQNext = Arrays.stream(qNext).max().orElse(0);
        q[aIdx] += ALPHA * (reward + GAMMA * maxQNext - q[aIdx]);

        if (stepCount % 500 == 0) save();
    }

    // -------------------------------------------------------------------------
    // Trainer feedback — called when YOU type /ai good or /ai bad
    // -------------------------------------------------------------------------

    public void trainerGood() {
        if (lastState == null || lastAction == null) return;
        double[] q = getQ(lastState.encode());
        q[lastAction.ordinal()] += ALPHA * REWARD_TRAINER_GOOD;
        ParkourAIMod.LOGGER.info("[ParkourAI] Trainer gave GOOD reward for {}", lastAction);
    }

    public void trainerBad() {
        if (lastState == null || lastAction == null) return;
        double[] q = getQ(lastState.encode());
        q[lastAction.ordinal()] += ALPHA * REWARD_TRAINER_BAD;
        ParkourAIMod.LOGGER.info("[ParkourAI] Trainer gave BAD reward for {}", lastAction);
    }

    // -------------------------------------------------------------------------
    // Demonstration / imitation mode
    // When enabled, we record your own movement choices and inject them as training data
    // -------------------------------------------------------------------------

    public void startTeachMode() {
        teachMode = true;
        teachBuffer.clear();
        ParkourAIMod.LOGGER.info("[ParkourAI] Teach mode ON — play the parkour and the bot will learn from you!");
    }

    public void stopTeachMode() {
        teachMode = false;
        // Replay the recorded demonstration into the Q-table with a large positive reward
        for (int[] pair : teachBuffer) {
            double[] q = getQ(pair[0]);
            q[pair[1]] = Math.max(q[pair[1]], REWARD_CHECKPOINT); // floor at checkpoint reward
        }
        ParkourAIMod.LOGGER.info("[ParkourAI] Teach mode OFF — absorbed {} steps from your demonstration.", teachBuffer.size());
        teachBuffer.clear();
        save();
    }

    /**
     * Record YOUR action in teach mode.
     * Called from BotController when it detects the player moving.
     */
    public void recordDemonstration(GameState state, Action inferredAction) {
        if (!teachMode) return;
        teachBuffer.add(new int[]{state.encode(), inferredAction.ordinal()});
    }

    public boolean isTeachMode() { return teachMode; }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private Action bestAction(GameState state) {
        double[] q = getQ(state.encode());
        int best = 0;
        for (int i = 1; i < q.length; i++) {
            if (q[i] > q[best]) best = i;
        }
        return Action.VALUES[best];
    }

    private double[] getQ(int stateKey) {
        return qTable.computeIfAbsent(stateKey, k -> new double[Action.COUNT]);
    }

    public int getQTableSize() { return qTable.size(); }
    public double getEpsilon() { return epsilon; }
    public int getStepCount() { return stepCount; }

    // -------------------------------------------------------------------------
    // Persistence — save/load Q-table
    // -------------------------------------------------------------------------

    public void save() {
        try {
            Files.createDirectories(SAVE_PATH.getParent());
            try (ObjectOutputStream oos = new ObjectOutputStream(
                    new BufferedOutputStream(Files.newOutputStream(SAVE_PATH)))) {
                oos.writeObject(new HashMap<>(qTable));
                oos.writeDouble(epsilon);
                oos.writeInt(stepCount);
            }
        } catch (IOException e) {
            ParkourAIMod.LOGGER.warn("[ParkourAI] Could not save Q-table: {}", e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    public void load() {
        if (!Files.exists(SAVE_PATH)) return;
        try (ObjectInputStream ois = new ObjectInputStream(
                new BufferedInputStream(Files.newInputStream(SAVE_PATH)))) {
            Map<Integer, double[]> loaded = (Map<Integer, double[]>) ois.readObject();
            qTable.putAll(loaded);
            epsilon = Math.max(EPSILON_MIN, ois.readDouble());
            stepCount = ois.readInt();
            ParkourAIMod.LOGGER.info("[ParkourAI] Loaded Q-table with {} states, epsilon={:.3f}",
                    qTable.size(), epsilon);
        } catch (Exception e) {
            ParkourAIMod.LOGGER.warn("[ParkourAI] Could not load Q-table: {}", e.getMessage());
        }
    }

    public void reset() {
        qTable.clear();
        epsilon = EPSILON_START;
        stepCount = 0;
        ParkourAIMod.LOGGER.info("[ParkourAI] Q-table reset.");
    }
}
