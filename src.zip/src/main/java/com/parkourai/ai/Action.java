package com.parkourai.ai;

/**
 * Every discrete action the bot can perform in a single tick.
 * Complex sequences (e.g. strafe-jump) are built from combinations.
 */
public enum Action {
    MOVE_FORWARD,
    MOVE_BACK,
    STRAFE_LEFT,
    STRAFE_RIGHT,
    JUMP,
    SPRINT_FORWARD,       // forward + sprint
    SPRINT_JUMP,          // forward + sprint + jump (the parkour special)
    TURN_LEFT_SMALL,      // -15 yaw
    TURN_RIGHT_SMALL,     // +15 yaw
    TURN_LEFT_LARGE,      // -45 yaw
    TURN_RIGHT_LARGE,     // +45 yaw
    STOP;                 // do nothing

    public static final Action[] VALUES = values();
    public static final int COUNT = VALUES.length;
}
