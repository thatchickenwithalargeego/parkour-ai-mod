package com.parkourai.ai;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;

import java.util.Arrays;

/**
 * A snapshot of the bot's sensory state.
 * This is what the Q-learning agent uses as input.
 *
 * We encode:
 *  - Is the bot on the ground?
 *  - Is there a block ahead / to the left / to the right / behind?
 *  - Is there air (gap) beneath the block ahead?
 *  - Velocity direction (moving toward goal or away)
 *  - Y delta to the remembered "goal" / next checkpoint
 */
public class GameState {

    // Discretised direction buckets: 0-7 (N, NE, E, SE, S, SW, W, NW)
    public final int facingOctant;
    public final boolean onGround;
    public final boolean blockAhead;
    public final boolean blockLeft;
    public final boolean blockRight;
    public final boolean gapAhead;     // block ahead has air beneath it (need to jump)
    public final boolean inAir;
    public final int yDeltaToGoal;     // clamped to [-3, +3]
    public final int distBucket;       // 0-4: how far from goal (rough)

    public GameState(boolean onGround, boolean blockAhead, boolean blockLeft,
                     boolean blockRight, boolean gapAhead, boolean inAir,
                     int facingOctant, int yDeltaToGoal, int distBucket) {
        this.onGround = onGround;
        this.blockAhead = blockAhead;
        this.blockLeft = blockLeft;
        this.blockRight = blockRight;
        this.gapAhead = gapAhead;
        this.inAir = inAir;
        this.facingOctant = facingOctant;
        this.yDeltaToGoal = yDeltaToGoal;
        this.distBucket = distBucket;
    }

    /**
     * Capture the current state from the game world.
     */
    public static GameState capture(MinecraftClient client, BlockPos goal) {
        if (client.player == null) return dummy();

        var player = client.player;
        var world = client.world;
        Vec3d pos = player.getPos();

        boolean onGround = player.isOnGround();
        boolean inAir = !onGround;

        // Facing direction (0-7)
        float yaw = (player.getYaw() % 360 + 360) % 360;
        int octant = Math.round(yaw / 45f) % 8;

        // Look one block ahead in the direction the player faces
        BlockPos ahead = getBlockInDirection(pos, yaw, 1);
        BlockPos aheadBelow = ahead.down();

        boolean blockAhead = world != null && !world.getBlockState(ahead).isAir();
        boolean gapAhead = world != null && world.getBlockState(aheadBelow).isAir()
                && !blockAhead;

        BlockPos leftPos = getBlockInDirection(pos, yaw - 90, 1);
        BlockPos rightPos = getBlockInDirection(pos, yaw + 90, 1);
        boolean blockLeft = world != null && !world.getBlockState(leftPos).isAir();
        boolean blockRight = world != null && !world.getBlockState(rightPos).isAir();

        // Distance / direction to goal
        int yDelta = 0;
        int distBucket = 4;
        if (goal != null) {
            double dx = goal.getX() - pos.x;
            double dz = goal.getZ() - pos.z;
            double dist = Math.sqrt(dx * dx + dz * dz);
            yDelta = (int) Math.max(-3, Math.min(3, goal.getY() - pos.y));
            distBucket = (int) Math.min(4, dist / 8);
        }

        return new GameState(onGround, blockAhead, blockLeft, blockRight,
                gapAhead, inAir, octant, yDelta, distBucket);
    }

    private static BlockPos getBlockInDirection(Vec3d pos, float yawDeg, int dist) {
        double rad = Math.toRadians(yawDeg);
        int x = (int) Math.floor(pos.x - Math.sin(rad) * dist);
        int y = (int) Math.floor(pos.y);
        int z = (int) Math.floor(pos.z + Math.cos(rad) * dist);
        return new BlockPos(x, y, z);
    }

    public static GameState dummy() {
        return new GameState(true, false, false, false, false, false, 0, 0, 4);
    }

    /**
     * Encode the state as an integer key for the Q-table HashMap.
     */
    public int encode() {
        int v = 0;
        v |= (onGround ? 1 : 0);
        v |= (blockAhead ? 1 : 0) << 1;
        v |= (blockLeft ? 1 : 0) << 2;
        v |= (blockRight ? 1 : 0) << 3;
        v |= (gapAhead ? 1 : 0) << 4;
        v |= (inAir ? 1 : 0) << 5;
        v |= (facingOctant & 7) << 6;        // 3 bits
        v |= ((yDeltaToGoal + 3) & 7) << 9;  // 3 bits, offset by 3
        v |= (distBucket & 7) << 12;          // 3 bits
        return v;
    }

    @Override
    public String toString() {
        return String.format(
            "State[ground=%b air=%b ahead=%b gap=%b yaw=%d yDelta=%d dist=%d]",
            onGround, inAir, blockAhead, gapAhead, facingOctant, yDeltaToGoal, distBucket
        );
    }
}
