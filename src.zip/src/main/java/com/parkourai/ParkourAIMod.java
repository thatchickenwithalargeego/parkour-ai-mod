package com.parkourai;

import com.parkourai.ai.ParkourAgent;
import com.parkourai.bot.BotController;
import com.parkourai.commands.TrainerCommands;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.MinecraftClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParkourAIMod implements ClientModInitializer {

    public static final String MOD_ID = "parkouraid";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // Singleton instances
    public static ParkourAgent agent;
    public static BotController botController;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[ParkourAI] Initialising...");

        agent = new ParkourAgent();
        botController = new BotController(agent);

        // Register tick event — this is the main game loop hook
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;
            botController.tick(client);
        });

        // Register chat listener — you type commands to train the bot
        TrainerCommands.register();

        LOGGER.info("[ParkourAI] Ready! Type /ai help in chat to see commands.");
    }
}
